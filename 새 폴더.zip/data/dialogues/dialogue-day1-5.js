export const dialogueDay1Part5= [
     {
  "image": "images/bg14.png",
  "talk": true,
  "name": "채은",
  "text": "(먼저 도착해 방탈출 카페에 앉아 기다리며 핸드폰을 만지작거렸다. 사람들이 하나둘 모이기 시작했다.)"
, "hideKakao": true},
  {
    "talk": true,
    "name": "남휘",
    "text": "안녕하세요~ 남휘입니다ㅎㅎ 오늘 잘 부탁드려요!"
, "hideKakao": true},
  {
    "talk": true,
    "name": "채은",
    "text": "아 네네~ 저도 잘 부탁드려요ㅎㅎ (처음 보는 얼굴이지만 금방 친해질 것 같은 느낌이었다.)"
, "hideKakao": true},
  {
    "talk": true,
    "name": "도연",
    "text": "저는 도연이에요! 저도 잘 부탁드려요~"
, "hideKakao": true},
  {
    "talk": true,
    "name": "채은",
    "text": "도연씨도 안녕하세요ㅎㅎ (조금 어색했지만, 괜히 기분이 좋았다.)"
, "hideKakao": true},
  {
    "talk": true,
    "name": "채은",
    "text": "(그때, 멀리서 혜정이 헐레벌떡 달려오는 게 보였다.)"
, "hideKakao": true},
  {
    "talk": true,
    "name": "혜정",
    "text": "헉 헉... 미안 늦었지! 지하철 깨빡세네 담배 한대만 피고 들어가자"
, "hideKakao": true},
  {
    "talk": true,
    "name": "채은",
    "text": "아냐아냐ㅋㅋㅋ 잘 왔다~ (이미 혼자 세대 폈음)"
 , "hideKakao": true},
  {
    "talk": true,
    "name": "혜정",
    "text": "얘들아~ 이쪽은 채은 언니! 나랑 제일 친한 패션과 언니야. 나보다 한 살 많고, 30살!ㅎㅎ"
, "hideKakao": true},
  {
    "talk": true,
    "name": "혜정",
    "text": "지수랑도 친해! 오늘 잘 부탁한다 얘들아ㅎㅎ"
, "hideKakao": true},
  {
    "talk": true,
    "name": "채은",
    "text": "(짧은 소개였지만 금세 분위기가 부드러워졌다.)"
, "hideKakao": true},
  {
    "talk": true,
    "name": "채은",
    "text": "나도ㅋㅋㅋ 다들 잘 부탁해요~ (여기서 혜정이가 제일 장신이라니)"
, "hideKakao": true}
];