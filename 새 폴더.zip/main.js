import context from './modules/core/context.js';
import initGameApp from './modules/core/gameApp.js';

initGameApp(context);
